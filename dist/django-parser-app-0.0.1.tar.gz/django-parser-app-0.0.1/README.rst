=================
django-parser-app
=================

parser_app has been created intending to upload XL files in a convenient manner.
This is a rest_framework based packege and is usuable in many projects.

Please visit original repo for more information: https://github.com/prantoamt/django-parser-app