django-parser-app
=================

parser\_app has been created intending to upload Excel files in a
convenient manner. This is a rest\_framework based packege and is
usuable in many projects.

For Quick Start and detailed information, please go through the original repo: https://github.com/prantoamt/django-parser-app